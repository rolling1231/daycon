"""Offline inference entrypoint for the action prediction competition."""

import csv
import json
from pathlib import Path
from typing import Any, Iterable

import joblib
import numpy as np


REQUIRED_KEYS = ("id", "session_meta", "history", "current_prompt")
MAX_CURRENT_PROMPT_CHARS = 4_000
MAX_HISTORY_ITEMS = 8
MAX_HISTORY_CHARS = 3_000
MAX_VALUE_CHARS = 800


def _clean_text(value: Any, max_chars: int = MAX_VALUE_CHARS) -> str:
    if value is None:
        return ""
    if isinstance(value, str):
        text = value
    elif isinstance(value, (dict, list, tuple)):
        try:
            text = json.dumps(value, ensure_ascii=False, sort_keys=True)
        except TypeError:
            text = str(value)
    else:
        text = str(value)
    text = " ".join(text.replace("\r", " ").replace("\n", " ").split())
    if max_chars and len(text) > max_chars:
        return text[:max_chars]
    return text


def _bucket_number(value: Any, bins: Iterable[int], prefix: str) -> str:
    bounds = list(bins)
    try:
        number = int(float(value))
    except (TypeError, ValueError):
        return f"{prefix}_unknown"
    for bound in bounds:
        if number <= bound:
            return f"{prefix}_le_{bound}"
    return f"{prefix}_gt_{bounds[-1]}"


def _path_tokens(paths: Any, max_paths: int = 10) -> list[str]:
    if not isinstance(paths, list):
        return []

    tokens: list[str] = []
    for raw_path in paths[-max_paths:]:
        path_text = _clean_text(raw_path, max_chars=200)
        if not path_text:
            continue
        suffix = Path(path_text).suffix.lower().lstrip(".")
        name = Path(path_text).name.lower()
        tokens.append(f"open_file {path_text}")
        if suffix:
            tokens.append(f"open_file_ext_{suffix}")
        if name:
            tokens.append(f"open_file_name_{name}")
    return tokens


def flatten_session_meta(meta: Any) -> str:
    if not isinstance(meta, dict):
        return ""

    parts: list[str] = []
    for key in ("user_tier", "language_pref"):
        value = _clean_text(meta.get(key), max_chars=80)
        if value:
            parts.append(f"{key} {value}")

    parts.append(_bucket_number(meta.get("budget_tokens_remaining"), [1_000, 5_000, 10_000, 25_000, 50_000, 100_000], "budget"))
    parts.append(_bucket_number(meta.get("turn_index"), [0, 1, 2, 4, 6, 8, 10, 12, 16], "turn"))
    parts.append(_bucket_number(meta.get("elapsed_session_sec"), [60, 180, 300, 600, 900, 1_800, 3_600], "elapsed"))

    workspace = meta.get("workspace")
    if isinstance(workspace, dict):
        parts.append(_bucket_number(workspace.get("loc"), [500, 2_000, 5_000, 10_000, 25_000, 50_000], "loc"))
        parts.append(f"git_dirty {bool(workspace.get('git_dirty'))}")

        ci_status = _clean_text(workspace.get("last_ci_status"), max_chars=80)
        if ci_status:
            parts.append(f"last_ci_status {ci_status}")

        language_mix = workspace.get("language_mix")
        if isinstance(language_mix, dict):
            try:
                lang_items = sorted(language_mix.items(), key=lambda item: float(item[1]), reverse=True)
            except (TypeError, ValueError):
                lang_items = list(language_mix.items())
            for lang, share in lang_items[:8]:
                lang_text = _clean_text(lang, max_chars=40)
                if lang_text:
                    parts.append(f"workspace_lang {lang_text}")
                try:
                    share_pct = int(round(float(share) * 100))
                    parts.append(f"workspace_lang_share_{lang_text}_{share_pct}")
                except (TypeError, ValueError):
                    pass

        parts.extend(_path_tokens(workspace.get("open_files")))

    return " | ".join(part for part in parts if part)


def _history_item_to_text(item: Any) -> str:
    if not isinstance(item, dict):
        return f"history_item {_clean_text(item)}"

    role = _clean_text(item.get("role"), max_chars=80) or "unknown"
    if role == "assistant_action":
        action = _clean_text(item.get("name"), max_chars=80)
        args = _clean_text(item.get("args"), max_chars=400)
        result = _clean_text(item.get("result_summary"), max_chars=300)
        return f"history_role {role} previous_action {action} action_args {args} action_result {result}"

    content = _clean_text(item.get("content"), max_chars=MAX_VALUE_CHARS)
    name = _clean_text(item.get("name"), max_chars=80)
    if name:
        return f"history_role {role} name {name} content {content}"
    return f"history_role {role} content {content}"


def flatten_history(history: Any) -> str:
    if not isinstance(history, list) or not history:
        return ""

    selected_reversed: list[str] = []
    used_chars = 0
    for item in reversed(history):
        text = _history_item_to_text(item)
        if not text:
            continue
        if selected_reversed and used_chars + len(text) > MAX_HISTORY_CHARS:
            break
        selected_reversed.append(text)
        used_chars += len(text)
        if len(selected_reversed) >= MAX_HISTORY_ITEMS:
            break

    return "\n".join(reversed(selected_reversed))


def extract_text(sample: dict[str, Any]) -> str:
    """Build the exact model input string used by both training and inference."""

    current_prompt = _clean_text(sample.get("current_prompt"), max_chars=MAX_CURRENT_PROMPT_CHARS)
    session_meta = flatten_session_meta(sample.get("session_meta"))

    sections = [
        f"session_meta: {session_meta}",
        f"current_prompt: {current_prompt}",
    ]
    return "\n".join(section for section in sections if section.strip())


def build_features(samples: Iterable[dict[str, Any]]) -> tuple[list[str], list[str]]:
    ids: list[str] = []
    texts: list[str] = []
    for sample in samples:
        ids.append(_clean_text(sample.get("id"), max_chars=200))
        texts.append(extract_text(sample))
    return ids, texts


def load_jsonl(path):
    """평가 데이터(jsonl) 로드. 한 줄당 샘플 하나."""
    samples = []
    with open(path, encoding="utf-8") as f:
        for line_no, line in enumerate(f, start=1):
            line = line.strip()
            if not line:
                continue
            try:
                obj = json.loads(line)
            except json.JSONDecodeError as e:
                raise ValueError(f"{path}:{line_no} JSON 파싱 실패: {e}")
            samples.append(obj)
    return samples


def validate_samples(samples):
    """필수 키 존재 여부 검증 (학습 데이터와 동일 스키마)."""
    n_bad = 0
    for s in samples:
        for k in REQUIRED_KEYS:
            if k not in s:
                n_bad += 1
                break
    if n_bad:
        print(f" 경고: 필수 키 누락 샘플 {n_bad}건 (빈 텍스트로 처리)")
    return n_bad


def load_sample_submission(path):
    """sample_submission.csv 로드 — 제출 파일의 id 순서/컬럼 기준."""
    with open(path, newline="", encoding="utf-8-sig") as f:
        reader = csv.DictReader(f)
        fieldnames = reader.fieldnames
        rows = list(reader)
    if fieldnames is None or fieldnames[:2] != ["id", "action"]:
        raise ValueError(
            f"sample_submission 컬럼이 (id, action)이 아님: {fieldnames}")
    return fieldnames, rows


def merge_predictions(sub_rows, ids, preds, fallback_action):
    """sample_submission의 id 순서에 맞춰 예측값 병합.

    예측에 없는 id는 fallback_action으로 채워 제출 action 공백을 방지한다.
    """
    pred_map = {str(sample_id): str(pred) for sample_id, pred in zip(ids, preds)}
    n_missing = 0
    for row in sub_rows:
        p = pred_map.get(str(row.get("id", "")))
        if p is None:
            n_missing += 1
            row["action"] = fallback_action
        else:
            row["action"] = p
    if n_missing:
        print(f" 경고: 예측이 없어 fallback으로 채운 id {n_missing}건")
    return sub_rows


def save_submission(path, fieldnames, rows):
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def first_existing(candidates, description):
    for candidate in candidates:
        candidate = Path(candidate)
        if candidate.exists():
            return candidate
    tried = ", ".join(str(Path(candidate)) for candidate in candidates)
    raise FileNotFoundError(f"{description}을 찾을 수 없습니다. 확인 경로: {tried}")


def predict_adam_softmax_model(model, texts, batch_size=4096):
    features = model["features"]
    weights = np.asarray(model["weights"], dtype=np.float32)
    bias = np.asarray(model["bias"], dtype=np.float32)
    classes = np.asarray(model["classes"])

    preds = []
    for start in range(0, len(texts), batch_size):
        batch_texts = texts[start:start + batch_size]
        x_batch = features.transform(batch_texts)
        scores = x_batch.dot(weights) + bias
        pred_idx = np.asarray(scores).argmax(axis=1)
        preds.extend(classes[pred_idx].tolist())
    return preds


def predict_model(model, texts):
    if isinstance(model, dict) and model.get("model_type") == "tfidf_adam_softmax":
        return predict_adam_softmax_model(model, texts)
    return model.predict(texts)


def get_model_classes(model):
    if isinstance(model, dict) and "classes" in model:
        return list(model["classes"])
    return list(getattr(model, "classes_", []))


def main():
    base_dir = Path(__file__).resolve().parent
    cwd = Path.cwd()
    model_filename = "tfidf_logreg.pkl"

    test_path = first_existing(
        [cwd / "data" / "test.jsonl", base_dir / "data" / "test.jsonl", base_dir.parent / "data" / "test.jsonl"],
        "test.jsonl",
    )
    sample_sub_path = first_existing(
        [
            cwd / "data" / "sample_submission.csv",
            base_dir / "data" / "sample_submission.csv",
            base_dir.parent / "data" / "sample_submission.csv",
        ],
        "sample_submission.csv",
    )
    model_path = first_existing(
        [cwd / "model" / model_filename, base_dir / "model" / model_filename],
        model_filename,
    )
    out_path = cwd / "output" / "submission.csv"

    print("Load model...")
    model = joblib.load(model_path)
    classes = get_model_classes(model)
    fallback_action = str(classes[0]) if classes else "edit_file"
    print(f" OK. path={model_path} classes={len(classes)}")

    print("Load test data...")
    samples = load_jsonl(test_path)
    validate_samples(samples)
    print(f" samples={len(samples)}")

    print("Build features...")
    ids, texts = build_features(samples)
    print(f" texts={len(texts)}")

    print("Inference model...")
    preds = predict_model(model, texts) if texts else []
    preds = [str(p) for p in preds]
    print(f" preds={len(preds)}")

    print("Build submission...")
    fieldnames, sub_rows = load_sample_submission(sample_sub_path)
    sub_rows = merge_predictions(sub_rows, ids, preds, fallback_action)
    save_submission(out_path, fieldnames, sub_rows)
    print(f"Saved: {out_path} (rows={len(sub_rows)})")


if __name__ == "__main__":
    main()
